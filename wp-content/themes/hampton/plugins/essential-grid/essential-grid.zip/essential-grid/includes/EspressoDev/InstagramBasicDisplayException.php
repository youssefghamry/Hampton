<?php

namespace EspressoDev;

class ESG_InstagramBasicDisplayException extends \Exception
{
	// ..
}
